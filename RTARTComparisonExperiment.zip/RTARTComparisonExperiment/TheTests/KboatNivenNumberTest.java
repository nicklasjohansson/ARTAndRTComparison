import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.*;
import java.util.stream.IntStream;
import java.util.stream.Stream;


class KboatNivenNumberTest {
    private static final int totalNumberOfCandidates = 50;
    private static final int min = -20;
    private static final int max = 200;

    KboatNivenNumber obj = new KboatNivenNumber();

    @ParameterizedTest
    @MethodSource("generateRange")
    void KboatNivenNumberControl(int testData) {
        Assertions.assertEquals(obj.checkNiven(testData), obj.faultyCheckNiven(testData));
    }

    private static int[] generateRange() {
        return IntStream.rangeClosed(min, max).toArray();
    }

    @ParameterizedTest
    @MethodSource("generateTestDataART")
    void KboatNivenNumberART(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.checkNiven(testData), obj.faultyCheckNiven(testData));
    }

    private static Stream<Integer> generateTestDataART() {
        long startTime = System.nanoTime();
        Set<Integer> selectedSet = new HashSet<>();
        List<Integer> testDataPoints = new ArrayList<>();
        Random random = new Random();
        int initialTestData = random.nextInt(max) + min;
        selectedSet.add(initialTestData);
        testDataPoints.add(initialTestData);
        for (int i = 0; i < totalNumberOfCandidates - 1; i++) {
            int testData = selectBestTestData(selectedSet);
            selectedSet.add(testData);
            testDataPoints.add(testData);
        }
        long endTime = System.nanoTime();
        System.out.println("Generation Time ART: " + (endTime - startTime));
        return testDataPoints.stream();
    }

    private static int selectBestTestData(Set<Integer> selectedSet) {
        int bestDistance = -1;
        Integer bestData = null;
        Set<Integer> candidateSet = new HashSet<>();
        Random random = new Random();

        for (int i = 0; i < totalNumberOfCandidates * 3; i++) {
            int candidate;
            do {

                candidate = random.nextInt(max) + min;

            } while (selectedSet.contains(candidate) || candidateSet.contains(candidate));

            candidateSet.add(candidate);
            int minCandidateDistance = Integer.MAX_VALUE;

            for (int j : selectedSet) {
                int distance = euclideanDistance(j, candidate);
                minCandidateDistance = Math.min(minCandidateDistance, distance);
            }

            if (bestDistance < minCandidateDistance) {
                bestData = candidate;
                bestDistance = minCandidateDistance;
            }
        }
        return bestData;
    }

    private static int euclideanDistance(int testData1, int testData2) {
        return Math.abs(testData1 - testData2);
    }

    private static Stream<Integer> generateTestDataRT() {
        long startTime = System.nanoTime();
        List<Integer> testDataPoints = new ArrayList<>();
        Random random = new Random();

        for (int i = 0; i < totalNumberOfCandidates; i++) {
            int testData = random.nextInt(max) + min;
            testDataPoints.add(testData);
        }
        long endTime = System.nanoTime();
        System.out.println("Generation Time RT: " + (endTime - startTime));
        return testDataPoints.stream();
    }

    @ParameterizedTest
    @MethodSource("generateTestDataRT")
    void KboatNivenNumberRT(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.checkNiven(testData), obj.faultyCheckNiven(testData));
    }
}