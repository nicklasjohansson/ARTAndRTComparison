public class KboatTwistedPrime {
    public boolean twistedPrime(int num) {
        if (num == 1) {
            return false;
        } else {
            boolean isPrime = true;
            for (int i = 2; i <= num / 2; i++) {
                if (num % i == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                int t = num;
                int revNum = 0;

                while (t != 0) {
                    int digit = t % 10;
                    t /= 10;
                    revNum = revNum * 10 + digit;
                }

                for (int i = 2; i <= revNum / 2; i++) {
                    if (revNum % i == 0) {
                        isPrime = false;
                        break;
                    }
                }
            }
            if (isPrime) {
                return true;
            } else {
                return false;
            }
        }
    }

    public boolean faultyTwistedPrime(int num) {
        if (num == 1 + 2) { //adds +2
            return false;
        } else {
            boolean isPrime = true;
            for (int i = 2; i <= num / 2; i++) {
                if (num % i == 0) {
                                //Removes isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                int t = num;
                int revNum = 0;

                while (t != 0) {
                    int digit = t % 10;
                    t /= 10;
                    revNum = revNum * 10 + digit;
                }

                for (int i = 2; i <= revNum / 2; i++) {
                    if (revNum % i == 0) {
                        isPrime = false;
                        break;
                    }
                }
            }
            if (isPrime) {
                return true;
            } else {
                return false;
            }
        }
    }
}
