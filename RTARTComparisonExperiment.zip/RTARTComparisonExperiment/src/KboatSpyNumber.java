public class KboatSpyNumber
{
    public boolean spyNumCheck(int num) {
        int digit, sum = 0;
        int orgNum = num;
        int prod = 1;

        while (num > 0) {
            digit = num % 10;

            sum += digit;
            prod *= digit;
            num /= 10;
        }

        if (sum == prod) {
            return true;
        } else {
            return false;
        }
    }


    public boolean faultySpyNumCheck(int num) {
        int digit, sum = 0;
        int orgNum = num;
        int prod = 1;

        while (num > 0) {
            digit = num % 9; // 10 to 9

            sum += digit;
            prod *= digit;
            num /= 10;
        }

        if (sum - 1 == prod + 1) { // adds -1 and + 1
            return true;
        } else {
            return false;
        }
    }
}