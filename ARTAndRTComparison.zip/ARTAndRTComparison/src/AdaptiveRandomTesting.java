import java.util.*;
import java.util.stream.Stream;

public class AdaptiveRandomTesting {
    private static final int totalNumberOfCandidates = 50;
    private static final int min = -20;
    private static final int max = 200;

    public static Stream<Integer> generateTestDataART() {
        long startTime = System.nanoTime();
        Set<Integer> selectedSet = new HashSet<>();
        List<Integer> testDataPoints = new ArrayList<>();
        Random random = new Random();
        int initialTestData = random.nextInt(max) + min;
        selectedSet.add(initialTestData);
        testDataPoints.add(initialTestData);
        for (int i = 0; i < totalNumberOfCandidates - 1; i++) {
            int testData = selectBestTestData(selectedSet);
            selectedSet.add(testData);
            testDataPoints.add(testData);
        }
        long endTime = System.nanoTime();
        System.out.println("Generation Time ART: " + (endTime - startTime));
        return testDataPoints.stream();
    }

        public static int selectBestTestData(Set<Integer> selectedSet) {
        int bestDistance = -1;
        Integer bestData = null;
        Set<Integer> candidateSet = new HashSet<>();
        Random random = new Random();

        for (int i = 0; i < totalNumberOfCandidates * 3; i++) {
            int candidate;
            do {

                candidate = random.nextInt(max) + min;

            } while (selectedSet.contains(candidate) || candidateSet.contains(candidate));

            candidateSet.add(candidate);
            int minCandidateDistance = Integer.MAX_VALUE;

            for (int j : selectedSet) {
                int distance = euclideanDistance(j, candidate);
                minCandidateDistance = Math.min(minCandidateDistance, distance);
            }

            if (bestDistance < minCandidateDistance) {
                bestData = candidate;
                bestDistance = minCandidateDistance;
            }
        }
        return bestData;
    }

    public static int euclideanDistance(int testData1, int testData2) {
        return Math.abs(testData1 - testData2);
    }
}
