import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

public class RandomTesting {

    private static final int totalNumberOfCandidates = 50;
    private static final int min = -20;
    private static final int max = 200;

    private static Stream<Integer> generateTestDataRT() {
        long startTime = System.nanoTime();
        List<Integer> testDataPoints = new ArrayList<>();
        Random random = new Random();

        for (int i = 0; i < totalNumberOfCandidates; i++) {
            int testData = random.nextInt(max) + min;
            testDataPoints.add(testData);
        }
        long endTime = System.nanoTime();
        System.out.println("Generation Time RT: " + (endTime - startTime));
        return testDataPoints.stream();
    }
}
