public class KboatAbundantNumber {

    public boolean abundantNumber(int n) {
        int sum = 0;

        for (int i = 1; i < n; i++) {
            if (n % i == 0) {
                sum += i;
            }
        }

        if (sum > n) {
            return true;
        } else {
            return false;
        }
    }


    public boolean faultyAbundantNumber(int n) {
        int sum = 1; // Changed from 0 to 1
        for (int i = 1; i < n; i++) { // Changed from < to <=
            if (n % i == 0) {
                sum += i + 3; // Added +3
            }
        }
        if (sum >= n) {
            return true;
        } else {
            return false;
        }
    }
}

