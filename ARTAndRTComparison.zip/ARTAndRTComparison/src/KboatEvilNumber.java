import java.util.Scanner;

public class KboatEvilNumber {
    public boolean evilNumber(int n) {
        if (n < 0) {
            return false;
        }

        int count = 0;
        int p = 0;
        int binNum = 0;

        while (n > 0) {
            int d = n % 2;
            if (d == 1)
                count++;
            binNum += (int) (d * Math.pow(10, p));
            p++;
            n /= 2;
        }


        if (count % 2 == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean faultyEvilNumber(int n) {
        if (n < 0) {
            return false;
        }
        int count = 0;
        int p = 0;
        int binNum = 0;
        while (n > 0) {
            int d = n % 2;
            if (d == 1)
                count++;
            binNum += (int) (d * Math.pow(10, p));
            p++;
            n /= 2;
        }
        if (count % 4 == 0) { // Changed from % 2 to % 4
            return true;
        } else {
            return false;
        }
    }
}