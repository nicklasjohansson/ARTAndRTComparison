import java.util.Scanner;

public class KboatPalindromeNumber {
    public boolean palindromeNumber(int num) {
        int copyNum = num;
        int revNum = 0;

        while (copyNum != 0) {
            int digit = copyNum % 10;
            copyNum /= 10;
            revNum = revNum * 10 + digit;
        }

        if (revNum == num) {
            return true;
        } else {
            return false;
        }
    }

    public boolean faultyPalindromeNumber(int num) {
        int copyNum = num;
        int revNum = 1; // Changed from 0 to 1
        while (copyNum != 0) {
            int digit = copyNum % 10;
            copyNum /= 9; // Changed from 10 to 9
            revNum = revNum * 10 + digit;
        }
        if (revNum == num) {
            return true;
        } else {
            return false;
        }
    }
}