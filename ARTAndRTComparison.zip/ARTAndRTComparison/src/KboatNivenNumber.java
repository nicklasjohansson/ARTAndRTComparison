public class KboatNivenNumber
{
    public boolean checkNiven(int num) {
        int orgNum = num;
        int digitSum = 0;
        while (num != 0) {
            int digit = num % 10;
            num /= 10;
            digitSum += digit;
        }
        if (digitSum != 0 && orgNum % digitSum == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean faultyCheckNiven(int num) {
        int orgNum = num;
        int digitSum = 0;
        while (num != 0) {
            int digit = num % 10;
            num /= 9; //Changed from 10 to 9
            digitSum += digit;
        }
        if (digitSum != 0 && orgNum % digitSum == 0) {
            return true;
        } else {
            return false;
        }
    }
}