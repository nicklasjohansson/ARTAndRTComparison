public class KboatBouncyNumber {
    public boolean bouncyNumber(int n) {
        if (n < 100) {
            return false;
        }
        int t = n;
        boolean isIncreasing = true, isDecreasing = true;
        int prev = t % 10;
        while (t != 0) {
            int d = t % 10;
            if (d > prev) {
                isIncreasing = false;
                break;
            }
            prev = d;
            t /= 10;
        }
        t = n;
        prev = t % 10;
        while (t != 0) {
            int d = t % 10;
            if (d < prev) {
                isDecreasing = false;
                break;
            }
            prev = d;
            t /= 10;
        }
        if (!isIncreasing && !isDecreasing) {
            return true;
        } else {
            return false;
        }
    }

    public boolean faultyBouncyNumber(int n) {
        if (n < 50) { // Changed from n < 100 to n < 50
            return false;
        }
        int t = n;
        boolean isIncreasing = true, isDecreasing = false; //Changed from isDecreasing = true to isDecreasing = false;
        int prev = t % 10;
        while (t != 0) {
            int d = t % 10;
            if (d > prev) {
                isIncreasing = false;
                break;
            }
            prev = d;
            t /= 10;
        }
        t = n;
        prev = t % 10;
        while (t != 0) {
            int d = t % 8; // Changed from t % 10 to t % 8
            if (d < prev) {
                isDecreasing = false;
                break;
            }
            prev = d;
            t /= 10;
        }
        if (!isIncreasing && !isDecreasing) {
            return true;
        } else {
            return false;
        }
    }
}
