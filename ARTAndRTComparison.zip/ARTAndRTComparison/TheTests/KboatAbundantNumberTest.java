import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.IntStream;

class KboatAbundantNumberTest {
    private static final int min = -20;
    private static final int max = 200;

    KboatAbundantNumber obj = new KboatAbundantNumber();

    @ParameterizedTest
    @MethodSource("generateRange")
    void KboatAbundantNumberControl(int testData) {
        Assertions.assertEquals(obj.abundantNumber(testData), obj.faultyAbundantNumber(testData));
    }

    private static int[] generateRange() {
        return IntStream.rangeClosed(min, max).toArray();
    }

    @ParameterizedTest
    @MethodSource("AdaptiveRandomTesting#generateTestDataART")
    void KboatAbundantNumberART(int testData) {
        System.out.println(testData);
        Assertions.assertEquals(obj.abundantNumber(testData), obj.faultyAbundantNumber(testData));
    }

    @ParameterizedTest
    @MethodSource("RandomTesting#generateTestDataRT")
    void KboatAbundantNumberRT(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.abundantNumber(testData), obj.faultyAbundantNumber(testData));
    }
}