import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.IntStream;

class KboatEvilNumberTest {
    private static final int totalNumberOfCandidates = 50;
    private static final int min = -20;
    private static final int max = 200;

    KboatEvilNumber obj = new KboatEvilNumber();

    @ParameterizedTest
    @MethodSource("generateRange")
    void KboatEvilNumberControl(int testData) {
        System.out.println(obj.evilNumber(testData));
        Assertions.assertEquals(obj.evilNumber(testData), obj.faultyEvilNumber(testData));
    }

    private static int[] generateRange() {
        return IntStream.rangeClosed(min, max).toArray();
    }

    @ParameterizedTest
    @MethodSource("AdaptiveRandomTesting#generateTestDataART")
    void KboatEvilNumberART(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.evilNumber(testData), obj.faultyEvilNumber(testData));
    }

    @ParameterizedTest
    @MethodSource("RandomTesting#generateTestDataRT")
    void KboatEvilNumberRT(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.evilNumber(testData), obj.faultyEvilNumber(testData));
    }
}