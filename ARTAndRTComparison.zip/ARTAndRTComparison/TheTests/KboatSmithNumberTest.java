import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.IntStream;


class KboatSmithNumberTest {
    private static final int min = -20;
    private static final int max = 200;

    KboatSmithNumber obj = new KboatSmithNumber();

    @ParameterizedTest
    @MethodSource("generateRange")
    void KboatSmithNumberControl(int testData) {
        Assertions.assertEquals(obj.smithNumber(testData), obj.faultySmithNumber(testData));
    }

    private static int[] generateRange() {
        return IntStream.rangeClosed(min, max).toArray();
    }

    @ParameterizedTest
    @MethodSource("AdaptiveRandomTesting#generateTestDataART")
    void KboatSmithNumberART(int testData) {
        Assertions.assertEquals(obj.smithNumber(testData), obj.faultySmithNumber(testData));
    }

    @ParameterizedTest
    @MethodSource("RandomTesting#generateTestDataRT")
    void KboatSmithNumberRT(int testData) {
        Assertions.assertEquals(obj.smithNumber(testData), obj.faultySmithNumber(testData));
    }

}