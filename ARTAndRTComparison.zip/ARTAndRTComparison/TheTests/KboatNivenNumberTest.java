import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.IntStream;


class KboatNivenNumberTest {
    private static final int min = -20;
    private static final int max = 200;

    KboatNivenNumber obj = new KboatNivenNumber();

    @ParameterizedTest
    @MethodSource("generateRange")
    void KboatNivenNumberControl(int testData) {
        Assertions.assertEquals(obj.checkNiven(testData), obj.faultyCheckNiven(testData));
    }

    private static int[] generateRange() {
        return IntStream.rangeClosed(min, max).toArray();
    }

    @ParameterizedTest
    @MethodSource("AdaptiveRandomTesting#generateTestDataART")
    void KboatNivenNumberART(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.checkNiven(testData), obj.faultyCheckNiven(testData));
    }

    @ParameterizedTest
    @MethodSource("RandomTesting#generateTestDataRT")
    void KboatNivenNumberRT(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.checkNiven(testData), obj.faultyCheckNiven(testData));
    }
}