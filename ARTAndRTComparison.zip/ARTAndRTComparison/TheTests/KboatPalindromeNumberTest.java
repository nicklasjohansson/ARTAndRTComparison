import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.IntStream;


class KboatPalindromeNumberTest {
    private static final int totalNumberOfCandidates = 50;
    private static final int min = -20;
    private static final int max = 200;

    KboatPalindromeNumber obj = new KboatPalindromeNumber();

    @ParameterizedTest
    @MethodSource("generateRange")
    void KboatPalindromeNumberControl(int testData) {
        Assertions.assertEquals(obj.palindromeNumber(testData), obj.faultyPalindromeNumber(testData));
    }

    private static int[] generateRange() {
        return IntStream.rangeClosed(min, max).toArray();
    }

    @ParameterizedTest
    @MethodSource("AdaptiveRandomTesting#generateTestDataART")
    void KboatPalindromeNumberART(int testData) {
        Assertions.assertEquals(obj.palindromeNumber(testData), obj.faultyPalindromeNumber(testData));
    }

    @ParameterizedTest
    @MethodSource("RandomTesting#generateTestDataRT")
    void KboatPalindromeNumberRT(int testData) {
        Assertions.assertEquals(obj.palindromeNumber(testData), obj.faultyPalindromeNumber(testData));
    }

}