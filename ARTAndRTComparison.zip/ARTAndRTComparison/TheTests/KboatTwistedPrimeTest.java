import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.IntStream;


class KboatTwistedPrimeTest {
    private static final int min = -20;
    private static final int max = 200;

    KboatTwistedPrime obj = new KboatTwistedPrime();

    @ParameterizedTest
    @MethodSource("generateRange")
    void KboatTwistedPrimeControl(int testData) {
        Assertions.assertEquals(obj.twistedPrime(testData), obj.faultyTwistedPrime(testData));
    }

    private static int[] generateRange() {
        return IntStream.rangeClosed(min, max).toArray();
    }

    @ParameterizedTest
    @MethodSource("AdaptiveRandomTesting#generateTestDataART")
    void KboatTwistedPrimeART(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.twistedPrime(testData), obj.faultyTwistedPrime(testData));
    }

    @ParameterizedTest
    @MethodSource("RandomTesting#generateTestDataRT")
    void KboatTwistedPrimeRT(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.twistedPrime(testData), obj.faultyTwistedPrime(testData));
    }
}