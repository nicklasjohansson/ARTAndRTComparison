import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.IntStream;


class KboatBouncyNumberTest {
    private static final int min = -20;
    private static final int max = 200;

    KboatBouncyNumber obj = new KboatBouncyNumber();

    @ParameterizedTest
    @MethodSource("generateRange")
    void KboatBouncyNumberControl(int testData) {
        Assertions.assertEquals(obj.bouncyNumber(testData), obj.faultyBouncyNumber(testData));
    }

    private static int[] generateRange() {
        return IntStream.rangeClosed(min, max).toArray();
    }

    @ParameterizedTest
    @MethodSource("AdaptiveRandomTesting#generateTestDataART")
    void KboatBouncyNumberART(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.bouncyNumber(testData), obj.faultyBouncyNumber(testData));
    }

    @ParameterizedTest
    @MethodSource("RandomTesting#generateTestDataRT")
    void KboatBouncyNumberRT(int testData) {
        System.out.println("Test data: " + testData);
        Assertions.assertEquals(obj.bouncyNumber(testData), obj.faultyBouncyNumber(testData));
    }
}