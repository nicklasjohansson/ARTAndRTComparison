import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.IntStream;


class KboatSpyNumberTest {
    private static final int min = -20;
    private static final int max = 200;

    KboatSpyNumber obj = new KboatSpyNumber();

    @ParameterizedTest
    @MethodSource("generateRange")
    void KboatSpyNumberControl(int testData) {
        Assertions.assertEquals(obj.spyNumCheck(testData), obj.faultySpyNumCheck(testData));
    }

    private static int[] generateRange() {
        return IntStream.rangeClosed(min, max).toArray();
    }

    @ParameterizedTest
    @MethodSource("AdaptiveRandomTesting#generateTestDataART")
    void KboatSmithNumberART(int testData) {
        Assertions.assertEquals(obj.spyNumCheck(testData), obj.faultySpyNumCheck(testData));
    }

    @ParameterizedTest
    @MethodSource("RandomTesting#generateTestDataRT")
    void KboatSpyNumberRT(int testData) {
        Assertions.assertEquals(obj.spyNumCheck(testData), obj.faultySpyNumCheck(testData));
    }

}